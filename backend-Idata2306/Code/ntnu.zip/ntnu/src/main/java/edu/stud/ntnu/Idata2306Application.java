package edu.stud.ntnu;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Idata2306Application {

	public static void main(String[] args) {
		SpringApplication.run(Idata2306Application.class, args);
	}

}
