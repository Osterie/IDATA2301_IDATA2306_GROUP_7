package edu.stud.ntnu;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Idata2306ApplicationTests {

	@Test
	void contextLoads() {
	}

}
